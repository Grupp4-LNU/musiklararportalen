=== MLP Musiklektion ===
Contributors: christoffer rydberg, simon ebeling, henrik petersson, musiklärarportalen
Tags: lesson
Requires at least: 3.5.1
Tested up to: 3.5.1
Stable tag: 3.5.1
License: GPLv2 or later

Musiklektioner custom post type

== Description ==

== Installation ==

== Changelog ==

= 1.0.0 =
